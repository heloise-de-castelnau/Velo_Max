﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MySql.Data.MySqlClient;
using System.Xml.Serialization;

namespace WPF_APP
{
    /// <summary>
    /// Logique d'interaction pour Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        #region ALL IS CLICKED
        //Vérifie que toutes les informations sont rentrés

        bool unablecheckbox = false;
        bool unabletextbox = false;
        bool unable_enter = false;
        
        
        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            unablecheckbox = true;

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (nom.Text != "")
            {
                unabletextbox = true;

            }
        }

        #endregion

        #region CONNECTION
        private void btnente_Click(object sender, RoutedEventArgs e)
        {

            if (unablecheckbox == true && unabletextbox == true)
            {
                unable_enter = true;
            }

            if (unable_enter == true)
            {
                string id = nom.Text;
                string mdp = password.Password;
                MySqlConnection maConnexion = null;
                try
                {
                    string connexionString = "SERVER=localhost;PORT=3306;" +
                                             "DATABASE=velomax;" +
                                             "UID=" + id + ";PASSWORD=" + mdp + ";";

                    maConnexion = new MySqlConnection(connexionString);
                    //maConnexion.Open();
                    Window1 win1 = new Window1(maConnexion, id);
                    win1.Show();

                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erreur de connexion");
                }
            }
            else
            {
                MessageBox.Show("Vous avez oublié de cocher un élément");
            }

        }
        #endregion
    }
}
