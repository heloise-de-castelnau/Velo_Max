﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Xml.Serialization;



namespace WPF_APP
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
       
    {
        bool buttonpage1 = false;
        bool buttonpage2 = false;
        public MainWindow()
        {
            
            InitializeComponent();

        }

        private void RadioButton_clientI_Checked(object sender, RoutedEventArgs e)
        {
            buttonpage1 = true;
        }

        private void RadioButton_clientB_Checked(object sender, RoutedEventArgs e)
        {
            buttonpage1 = true;
        }

        private void RadioButton_Admin_Checked(object sender, RoutedEventArgs e)
        {
            buttonpage1 = true;
        }

        private void RadioButton_NvClient_Checked(object sender, RoutedEventArgs e)
        {
            buttonpage2 = true;
        }

        private void Valide_Click(object sender, RoutedEventArgs e)
        {
            if(buttonpage1 == true)

            {
                this.Visibility = Visibility.Hidden;
                Window2 win2 = new Window2();
                win2.Show();
            }
            if (buttonpage2 == true)

            {
                MessageBox.Show("Not Created Yet");
            }
        }
    }
}
